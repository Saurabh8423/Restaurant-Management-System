import React from "react";
import "./OrderCard.css";

export default function OrderCards({ orders = [] }) {
  const processingOrders = orders.filter((o) => o.status === "Processing");
  const doneOrders = orders.filter((o) => o.status === "Order Done");

  return (
    <div className="order-section">

      {/* Processing Orders */}
      <div className="order-group">
        <h3>Processing</h3>
        <div className="order-grid">
          {processingOrders.length > 0 ? (
            processingOrders.map((order) => (
              <OrderCard key={order._id} order={order} />
            ))
          ) : (
            <p className="empty-text">No Processing Orders</p>
          )}
        </div>
      </div>

      {/* Order Done */}
      <div className="order-group">
        <h3>Order Done</h3>
        <div className="order-grid">
          {doneOrders.length > 0 ? (
            doneOrders.map((order) => <OrderCard key={order._id} order={order} />)
          ) : (
            <p className="empty-text">No Completed Orders</p>
          )}
        </div>
      </div>
    </div>
  );
}

const OrderCard = ({ order }) => {
  const { orderNo, tableNo, time, items = [], type, status, ongoingTime } = order;
  const totalItems = items.reduce((sum, i) => sum + (i.quantity || 0), 0);
  const isProcessing = status === "Processing";

  return (
    <div className={`order-card ${isProcessing ? "processing" : "done"}`}>
      {/* Header Section */}
      <div className="order-header">
        <div className="order-left">
          <p className="order-id">#{orderNo}</p>
          <p className="order-table">{tableNo}</p>
          <p className="order-time">{time}</p>
          <p className="order-items">{totalItems} Item{totalItems > 1 ? "s" : ""}</p>
        </div>

        <div className="order-right">
          <div
            className={`order-type ${
              isProcessing ? "type-processing" : "type-done"
            }`}
          >
            <p>{type}</p>
            <small>
              {isProcessing ? `Ongoing: ${ongoingTime}` : "Completed"}
            </small>
          </div>
        </div>
      </div>

      {/* Items Section */}
      <div className="order-body">
        {items.map((item, index) => (
          <div key={item._id || index} className="order-item">
            <p>
              {item.quantity} × {item.name}
            </p>
            <small>₹{item.price}</small>
          </div>
        ))}
      </div>

      {/* Footer Section */}
      <div
        className={`order-footer ${
          isProcessing ? "footer-processing" : type === "Take Away"
            ? "footer-gray"
            : "footer-done"
        }`}
      >
        {isProcessing ? (
          <p>Done Served 🍽️</p>
        ) : type === "Take Away" ? (
          <p>Not Picked Up 🕒</p>
        ) : (
          <p>Done Served ✅</p>
        )}
      </div>
    </div>
  );
};
